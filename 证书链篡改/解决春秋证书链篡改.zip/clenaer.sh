#!/system/bin/sh


TARGET_PATHS=(
  "/data/media/0/Android/data"
  "/data/media/0/Android/media"
  "/data/media/0/Android/obb"
)
EXCLUDE_DIRS=("com.termux" "com.android.providers.downloads")
CLEAN_LOG="/data/local/tmp/clean_empty.log"

clean_empty_dirs() {
  echo "\n=== 空目录清理开始 $(date) ===" >> "$CLEAN_LOG"
  for path in "${TARGET_PATHS[@]}"; do
    echo "处理路径: $path" >> "$CLEAN_LOG"
    find "$path" -mindepth 1 -maxdepth 1 -type d | while IFS= read -r dir; do
      dir_name=${dir##*/}
      if echo " ${EXCLUDE_DIRS[*]} " | grep -qE "\<${dir_name}\>"; then
        echo "[保护] $dir_name" >> "$CLEAN_LOG"
        continue
      fi
      [ -z "$(ls -A "$dir")" ] && {
        echo "[删除] $dir_name" >> "$CLEAN_LOG"
        rm -rf -- "$dir"
      }
    done
  done
}


SMALL_TARGET_DIRS=(
  "/storage/emulated/0/Android/data"
  "/storage/emulated/0/Android/media"
  "/storage/emulated/0/Android/obb"
)
SIZE_LIMIT=20  # KB
PROTECT_PATTERNS=("com.android.*" "com.google.*" "android" "*.nomedia" "*.obb")

clean_small_dirs() {
  for dir in "${SMALL_TARGET_DIRS[@]}"; do
    [ ! -d "$dir" ] && continue
    find "$dir" -mindepth 1 -maxdepth 1 -type d | while IFS= read -r dir_path; do
      name=${dir_path##*/}
      for pattern in "${PROTECT_PATTERNS[@]}"; do
        case "$name" in $pattern)
          continue 2
        esac
      done
      size=$(du -sk "$dir_path" | cut -f1)
      [ "$size" -lt "$SIZE_LIMIT" ] && rm -rf -- "$dir_path"
    done
  done
}


DELETE_PATHS=(
 DELETE_PATHS=(

  "/data/nh/"          "/data/nh5/"         "/data/nh6/"
  "/data/nh2/"         "/data/nh3/"         "/data/nh4/"
  "/data/nh.ko"        "/data/gamepad_driver.so"
  "/sdcard/elgg/"      "/data/BingPUBG/"    "/data/BingHPJY/"
  "/data/jz/"          "/data/jz.sh"
  "/data/system/liboxmem.so"
  "/data/local/tmp/gamepad_driver.so"
  "/system/lib/hid/gamepad_driver.so"
  "/data/.gamepad_driver_installed"
  "/data/system/liborangeinit.so"
  "/data/system/xydriver.ko"
  "/data/BingPUBG/guns.cfg"
  "/data/BingHPJY/pz.cfg"
  "/dev/Bing/"
  "/data/单发枪配置.txt"
  "/data/local/tmp/单发枪配置.txt"
  "/data/A内核.ini"   "/data/物资.txt"
  "/data/HPX/"        "/data/HPY/"
  "/data/system/HPX/" "/data/system/HPY/"
  "/storage/emulated/0/落叶配置/"
  "/storage/emulated/0/BY物资/"
  "/storage/emulated/0/落叶配置/落叶配置.txt"
  "/storage/emulated/0/BY物资/BY物资.txt"
  "/storage/emulated/elgg/"
  "/storage/emulated/0/Download/WechatXposed/"


  "/data/nh" "/data/nh2" "/data/nh3" "/data/nh4" "/data/nh5"
  "/data/js" "/data/js.sh"
  "/data/HPX" "/data/HPY"
  "/data/system/HPX" "/data/system/HPY"
  "/data/BingPUBG"
  "/data/local/stryker/"
  "/data/system/AppRetention"
  "/data/local/tmp/luckys"
  "/data/local/tmp/HyperCeiler"
  "/data/local/tmp/simpleHook"
  "/data/local/tmp/DisabledAllGoogleServices"
  "/data/local/MIO"
  "/data/DNA"
  "/data/local/tmp/cleaner_starter"
  "/data/local/tmp/byyang"
  "/data/local/tmp/mount_mask"
  "/data/local/tmp/mount_mark"
  "/data/local/tmp/scriptTMP"
  "/data/local/luckys"
  "/data/local/tmp/horae_control.log"
  "/data/gpu_freq_table.conf"
  "/storage/emulated/0/Download/advanced/"
  "/storage/emulated/0/Documents/advanced/"
  "/data/system/NoActive/"
  "/data/system/Freezer/"
  "/storage/emulated/0/Android/naki/"
  "/data/swap_config.conf"
  "/data/local/tmp/resetprop"
  "/dev/cpuset/AppOpt/"
  "/storage/emulated/0/Android/Clash/"
  "/storage/emulated/0/Android/Yume-Yunyun/"
  "/data/local/tmp/Surfing_update"
  "/data/encore/custom_default_cpu_gov"
  "/data/encore/default_cpu_gov"
  "/data/local/tmp/yshell"
  "/data/local/tmp/encore_logo.png"
  "/storage/emulated/legacy/"
  "/data/system/junge/"
  "/storage/emulated/0/TpTestReport/screenOn/OK/0/"
  "/sdcard/TWRP"
  "/storage/emulated/0/Android/HChai/"
  "/storage/emulated/0/rlgg/"
  "/system/bin/run_write.sh"
  "/system/bin/imgbox"
  "/system/bin/adb"
  "/system/bin/fastboot"
  "/system/bin/scene_swap_module.sh"
  "/system/bin/gmsc"
  "/system/bin/encore_profiler"
  "/system/bin/encore_utility"
  "/data/local/tmp/android_server"
  "/data/local/tmp/android_server64"
  "/data/local/tmp/gdbserver"
  "/sdcard/fart"
  "/sdcard/Download/dexdump/"
  "/sdcard/Download/com.niunaijun.blackdexa32_logcat.txt"
  "/sdcard/Download/com.niunaijun.blackdexa64_logcat.txt"
)
)

delete_specified_paths() {
  for path in "${DELETE_PATHS[@]}"; do
    [ -e "$path" ] || continue
    rm -rf -- "$path" 2>/dev/null
  done
}

clean_empty_dirs
clean_small_dirs
delete_specified_paths