#!/system/bin/sh
MODDIR=${0%/*}

TRICKY_PKGS="com.chunqiunativecheck"

ensure_tricky_store_targets() {
  local dir="/data/adb/tricky_store"
  local file="$dir/target.txt"
  mkdir -p "$dir"
  [ -f "$file" ] || touch "$file"
  for pkg in $TRICKY_PKGS; do
    if ! grep -qxF "$pkg" "$file" 2>/dev/null; then
      echo "$pkg" >> "$file"
    fi
  done
}
ensure_tricky_keybox() {
  local dir="/data/adb/tricky_store"
  local dst="$dir/keybox.xml"
  local src="$MODDIR/keybox.xml"

  [ -f "$src" ] || return 0  
  mkdir -p "$dir"

  if [ ! -f "$dst" ]; then
    cp -f "$src" "$dst"
    chmod 0644 "$dst"
  fi
}
#弱隐藏bl 
resetprop ro.boot.flash.locked 1
resetprop ro.boot.verifiedbootstate green
resetprop ro.secureboot.lockstate locked
resetprop ro.boot.vbmeta.device_state locked
ensure_tricky_store_targets
ensure_tricky_keybox
/system/bin/sh "$MODDIR/cleaner.sh" >/dev/null 2>&1
while true; do
  /system/bin/sh "$MODDIR/cleaner.sh" >/dev/null 2>&1
  sleep 60
done