#!/system/bin/sh

# 定义路径
MT_PATH="/storage/emulated/0/"
FOLDER_PATH="${MT_PATH}MT2"
TRICKY_DATA="/data/adb/tricky_store"
FOUND_FILES=$(find "$MT_PATH" -maxdepth 1 -type f \( -name "*.xml" -o -name "*.img" -o -name "*.sh" \) 2>/dev/null)

sleep 0.3

# bl弱级隐藏
resetprop -n ro.boot.flash.locked 1
resetprop -n ro.boot.verifiedbootstate green
resetprop -n ro.boot.vbmeta.device_state locked
echo "[✓] 弱级伪装bl为已锁定"
sleep 0.3

# 修复密钥26
PATCH_DATE=$(getprop ro.build.version.security_patch)
echo " 正在修复 trampered attestation key ..."
sleep 1
mkdir -p "$TRICKY_DATA"
rm -f "$TRICKY_DATA/security_patch.txt"
{
    echo "system=prop"
    echo "boot=$PATCH_DATE"
    echo "vendor=$PATCH_DATE"
} > "$TRICKY_DATA/security_patch.txt"
chmod 644 "$TRICKY_DATA/security_patch.txt"
echo "[✓] 安全补丁日期已同步: $PATCH_DATE"
sleep 0.3

# 配置target.txt
{
        echo "com.google.android.gms!"
        echo "com.android.vending!"
        pm list packages -3 | sed 's/^package://;s/$/!/'
    } > "$TRICKY_DATA/target.txt"
    sleep 1
    echo "[✓] 已对所有应用开启密钥生成模式"
sleep 0.3

# setprop logedsize
echo " 正在恢复系统环境..."
for prop in persist.logd.size persist.logd.size.crash persist.logd.size.system persist.logd.size.main; do
    setprop "$prop" ""
done
sleep 0.3
echo "[✓] 系统缓存空间已恢复"
sleep 0.3

# 关闭USB调试
settings put global adb_enabled 0
echo "[✓] 已关闭USB调试"
sleep 0.3

# risk files
print_msg() {
    echo -e "${BLUE}$1${NC}"
}

if [ -d "$FOLDER_PATH" ] || [ -n "$FOUND_FILES" ]; then
    echo -e "\n${RED}[!] 发现以下残留可能导致检测：${NC}"
    if [ -d "$FOLDER_PATH" ]; then echo -e "  文件夹: ${YELLOW}$FOLDER_PATH${NC}"; fi
    
    echo "$FOUND_FILES" | while read -r f; do
        [ -z "$f" ] && continue
        echo -e "  文件: ${YELLOW}$f${NC}"
    done
    
    echo -e "\n${BOLD}${RED}请使用音量键选择：${NC}"
    print_msg "❗ 单击音量上键清理所有残留文件" "❗ Press volume up to clean all residual files"
    print_msg "❗ 单击音量下键跳过清理（不推荐）" "❗ Press volume down to skip cleaning (not recommended)"
    echo " ----------------------------------------------------------"
    
    count=30
    key_click=""
    while [ $count -gt 0 ] && [ -z "$key_click" ]; do
         sleep 0.3
         count=$((count - 1))
         key_click="$(timeout 0.1 getevent -qlc 1 2>/dev/null | awk '{ print $3 }' | grep 'KEY_')"
    done
    
    if [ -z "$key_click" ]; then
         key_click="KEY_VOLUMEDOWN"
    fi
    
    case "$key_click" in
        "KEY_VOLUMEUP")
            echo -e "\n${BLUE}[*] 正在清理...${NC}"
            if [ -d "$FOLDER_PATH" ]; then 
                rm -rf "$FOLDER_PATH" && echo -e "  已删除文件夹: MT2"
            fi
            echo "$FOUND_FILES" | while read -r file; do
                if [ -f "$file" ]; then
                    rm -f "$file" && echo -e "  已删除文件: $(basename "$file")"
                fi
            done
            echo -e "${GREEN}[✓] 清理完成${NC}"
            ;;
        *)
            echo -e "\n${PURPLE}[i] 已跳过清理，请注意风险。${NC}"
            ;;
    esac
fi
echo "[✓] 未检测到risk file"

echo 'Done'