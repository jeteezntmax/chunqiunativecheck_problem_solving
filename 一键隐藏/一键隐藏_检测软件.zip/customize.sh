#!/system/bin/sh

# 定义路径
MOD_DIR="$MODPATH/file/modules"
KEY_DIR="$MODPATH/file/keybox"
HMA_DIR="$MODPATH/file/hma-oss"
KSUD_BIN="/data/adb/ksud"
TRICKY_DATA="/data/adb/tricky_store"
APK_DIR="$MODPATH/file/apks"
OTHER_FILES="$MODPATH/file/otherfiles"

# 判断当前是否为ksu环境
if [ -f "$KSUD_BIN" ]; then
    echo "检测到KSU环境，脚本安装继续"
    sleep 1
else
    echo "当前不是KSU环境，本模块只适用于KSU"
    exit 1
fi

# 定义函数
install_module() {
            local name="$1"
            local file="$MOD_DIR/$2"
            echo "[#] 正在刷入: $name"
            sleep 1
            if [ -f "$file" ]; then
                "$KSUD_BIN" module install "$file"
                echo "[✓] $name 已安装"
            else
                echo "[!] 缺失文件: $file"
            fi
            sleep 0.5
        }
        sleep 1
        

# 声明
COUNT=1
while [ $COUNT -le 5 ]; do
    echo "[◇] Made By JeTeeZnTmax 倒卖可耻"
    sleep 0.1
    COUNT=$((COUNT + 1))
done
sleep 0.5
# start

        echo ""
        echo "--- 开始刷入模块 ---"
        sleep 1
        install_module "ZygiskNext" "ZygiskNext.zip"
        install_module "LSPosed" "LSposed.zip"
        install_module "TEE Simulator RS" "TEESimulatorRS.zip"
        sleep 1

        # 配置Keybox & Target
        if [ -f "$KEY_DIR/keybox.xml" ]; then
            cp -f "$KEY_DIR/keybox.xml" "$TRICKY_DATA/keybox.xml"
            chmod 644 "$TRICKY_DATA/keybox.xml"
            sleep 1
            echo "[✓] Keybox 已更新"
        fi

        {
            echo "com.google.android.gms!"
            echo "com.android.vending!"
            pm list packages -3 | sed 's/^package://;s/$/!/'
        } > "$TRICKY_DATA/target.txt"
        sleep 1
        echo "[✓] 密钥生成模式已对所有应用开启"

        # 安装tricky store寄生模块
        install_module "TrickyAddon" "TrickyAddonModule.zip"
        echo "[✓] tricky store寄生模块已安装"

        # 修复密钥26
        PATCH_DATE=$(getprop ro.build.version.security_patch)
        echo ""
        echo "[*] 正在修复 trampered attestation key ..."
        sleep 1
        mkdir -p "$TRICKY_DATA"
        rm -f "$TRICKY_DATA/security_patch.txt"
        {
            echo "system=prop"
            echo "boot=$PATCH_DATE"
            echo "vendor=$PATCH_DATE"
        } > "$TRICKY_DATA/security_patch.txt"
        chmod 644 "$TRICKY_DATA/security_patch.txt"
        echo "[✓] 安全补丁日期已同步: $PATCH_DATE"
        sleep 1

        # setprop
        echo ""
        echo "[*] 正在恢复系统环境..."
        for prop in persist.logd.size persist.logd.size.crash persist.logd.size.system persist.logd.size.main; do
            setprop "$prop" ""
        done
        sleep 0.5
        echo "[✓] 系统缓存空间已恢复"
        sleep 0.5
        
        # 开启隐藏selinux修改
        echo '尝试开启隐藏selinux修改'
        "$KSUD_BIN" feature set selinux_hide 1  2>&1
        "$KSUD_BIN" feature save  2>&1
        sleep 0.5
        
        # 隐藏应用列表
        echo '安装隐藏应用列表'
        install_module "HMA-OSS" "HMA-OSS.zip"
        sleep 1
        # 配置config.json
        echo '配置config.json'
        DIRS=$(find /data/misc -maxdepth 1 -type d -name "hide_my_applist_*" 2>/dev/null)
        cp -f "$HMA_DIR/config.json" "$DIRS/config.json"

        # mt2/异常文件
        MT_PATH="/storage/emulated/0/"
        FOLDER_PATH="${MT_PATH}MT2"
        FOUND_FILES=$(find "$MT_PATH" -maxdepth 1 -type f \( -name "*.xml" -o -name "*.img" -o -name "*.sh" \) 2>/dev/null)
        sleep 1

        print_msg() {
            echo "$1"
        }

        if [ -d "$FOLDER_PATH" ] || [ -n "$FOUND_FILES" ]; then
            echo ""
            echo "[!] 发现以下残留可能导致检测："
            if [ -d "$FOLDER_PATH" ]; then echo "  文件夹: $FOLDER_PATH"; fi

            echo "$FOUND_FILES" | while read -r f; do
                [ -z "$f" ] && continue
                echo "  文件: $f"
            done

            echo ""
            echo "请使用音量键选择："
            print_msg "[音量上键]：清理所有残留文件"
            print_msg "[音量下键]：跳过清理（不推荐）"
            echo " ----------------------------------------------------------"

            count=30
            key_click=""
            while [ $count -gt 0 ] && [ -z "$key_click" ]; do
                sleep 0.3
                count=$((count - 1))
                key_click="$(timeout 0.1 getevent -qlc 1 2>/dev/null | awk '{ print $3 }' | grep 'KEY_')"
            done

            if [ -z "$key_click" ]; then
                key_click="KEY_VOLUMEDOWN"
            fi

            case "$key_click" in
                "KEY_VOLUMEUP")
                    echo ""
                    echo "[*] 正在清理..."
                    if [ -d "$FOLDER_PATH" ]; then
                        rm -rf "$FOLDER_PATH" && echo "  已删除文件夹: MT2"
                    fi
                    echo "$FOUND_FILES" | while read -r file; do
                        if [ -f "$file" ]; then
                            rm -f "$file" && echo "  已删除文件: $(basename "$file")"
                        fi
                    done
                    echo "[✓] 清理完成"
                    ;;
                *)
                    echo ""
                    echo "[i] 已跳过清理，请注意风险。"
                    ;;
            esac
        fi
        echo "[✓] 未检测到risk file"

        # 定义mt2目录
        MT_CONF="/data/user/0/bin.mt.plus/shared_prefs/bin.mt.plus_preferences.xml"
        if [ -f "$MT_CONF" ]; then
            sed -i '/mt2_path/d' "$MT_CONF"
            sed -i '/<\/map>/i \    <string name="mt2_path">/data/adb</string>' "$MT_CONF"
            sleep 0.5
            echo "[✓] 已自定义mt2目录"
        else
            sleep 0.5
            echo "[✓] 无需更改mt2目录"
        fi

        # 复制resetprop脚本到service.d
        echo "配置每次开机执行的属性修复中"
        cp -f "$OTHER_FILES/resetprop.sh" "/data/adb/service.d/resetprop.sh"
        echo "完成"
        sleep 0.5
        
        # 复制zygisknext_set脚本到service.d
        echo "配置重启后修改zygisk next配置"
        cp -f "$OTHER_FILES/zygisknext_set.sh" "/data/adb/service.d/zygisknext_set.sh"
        echo "完成"
        sleep 0.5
        
        # 复制tricky_store自动更新包名脚本到service.d
        echo "配置tricky_store自动更新包名列表"
        cp -f "$OTHER_FILES/tricky_store自动更新包名列表.sh" "/data/adb/service.d/tricky_store自动更新包名列表.sh"
        echo "完成"
        sleep 0.5
        
        # 为欧加真设备备份ocdt分区
        if [ -e /dev/block/by-name/ocdt ]; then
        echo "检测到欧加真设备，正在为您备份ocdt分区..."
        mkdir -p /sdcard/imagine_backup
        dd if=/dev/block/by-name/ocdt of=/sdcard/imagine_backup/ocdt_backup.img bs=4M conv=fsync
        sleep 1
        echo "备份成功~请务必上传到云盘/其他设备以便以后可能出现的救砖"
        sleep 0.5
        else
        sleep 0.1
        fi
        
echo "清理安装残留ing"
rm -rf "$MODPATH/file"
sleep 1
echo "完成"
sleep 0.5
echo "      ✨ 任务全部完成！请重启手机生效 ✨     "
sleep 1