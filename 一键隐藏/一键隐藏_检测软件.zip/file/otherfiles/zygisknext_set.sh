#!/system/bin/sh
sleep 10

echo 2 > /data/adb/zygisksu/denylist_enforce
echo 1 > /data/adb/zygisksu/memory_type

rm -rf "/data/adb/service.d/zygisknext_set.sh"
