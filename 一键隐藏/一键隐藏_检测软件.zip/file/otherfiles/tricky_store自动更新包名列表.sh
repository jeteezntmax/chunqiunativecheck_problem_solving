#!/system/bin/sh

sleep 5

export PATH=/sbin:/system/bin:/system/xbin:$PATH

TRICKY_DATA="/data/adb/tricky_store"
FIXED="$TRICKY_DATA/tricky_target.sh"
TARGET="$TRICKY_DATA/target.txt"
CONFIG="$TRICKY_DATA/自动更新包名.txt"
LOG="$TRICKY_DATA/target_update.log"
PID_FILE="$TRICKY_DATA/target_watcher.pid"
INTERVAL=10

mkdir -p "$TRICKY_DATA"

if [ ! -f "$CONFIG" ]; then
    printf '是否启用自动更新包名(0关闭/1启用)？\n1\n' > "$CONFIG"
    chmod 644 "$CONFIG"
fi

log() {
    echo "$(date '+%m-%d %H:%M:%S') $*" >> "$LOG" 2>/dev/null
}

case "$0" in
    /*) SELF="$0" ;;
    *)  SELF="$(pwd)/$0" ;;
esac
SELF="$(readlink -f "$SELF" 2>/dev/null || echo "$SELF")"

SCRIPT_PATH="$SELF"
if [ ! -f "$SCRIPT_PATH" ] || ! grep -q 'TRICKY_DAEMON' "$SCRIPT_PATH" 2>/dev/null; then
    if [ -f "$SELF" ] && grep -q 'TRICKY_DAEMON' "$SELF" 2>/dev/null; then
        cp "$SELF" "$FIXED" 2>/dev/null && chmod 755 "$FIXED"
        SCRIPT_PATH="$FIXED"
        log "已自动部署脚本到 $SCRIPT_PATH"
    else
        SCRIPT_PATH="$FIXED"
        log "警告: 无法定位脚本自身, daemon 将使用 $SCRIPT_PATH (请确认该文件存在)"
    fi
fi

read_config() {
    val="$(sed -n '2p' "$CONFIG" 2>/dev/null | tr -d '\r\n ')"
    case "$val" in
        1) echo enabled ;;
        0) echo disabled ;;
        *) echo invalid ;;
    esac
}

get_pkgs() {
    pm list packages -3 2>/dev/null | sed 's/^package://;s/$/!/' | sort -u
}

sync_target() {
    command -v pm >/dev/null 2>&1 || { log "pm 不可用, 跳过"; return 1; }

    cur="$(get_pkgs)"
    [ -n "$cur" ] || { log "三方列表为空, 跳过"; return 1; }

    if [ -f "$TARGET" ]; then
        old="$(grep -vE '^(com\.google\.android\.gms|com\.android\.vending)!$' "$TARGET" | sort -u)"
    else
        old=""
    fi

    printf '%s\n' "$old" > /data/local/tmp/tricky_old.list
    printf '%s\n' "$cur" > /data/local/tmp/tricky_cur.list

    added="$(comm -13 /data/local/tmp/tricky_old.list /data/local/tmp/tricky_cur.list)"
    removed="$(comm -23 /data/local/tmp/tricky_old.list /data/local/tmp/tricky_cur.list)"

    if [ -n "$added" ] || [ -n "$removed" ]; then
        {
            echo "com.google.android.gms!"
            echo "com.android.vending!"
            printf '%s\n' "$cur"
        } > "$TARGET.tmp"
        mv "$TARGET.tmp" "$TARGET"
        chmod 644 "$TARGET"
        [ -z "$added" ]   || log "新增: $(echo "$added" | tr '\n' ' ')"
        [ -z "$removed" ] || log "移除: $(echo "$removed" | tr '\n' ' ')"
    fi
    rm -f /data/local/tmp/tricky_old.list /data/local/tmp/tricky_cur.list
}

if [ "$TRICKY_DAEMON" = "1" ]; then
    echo "$$" > "$PID_FILE"
    log "daemon 上线 pid=$$"
    PREV=""
    while true; do
        state="$(read_config)"
        if [ "$state" != "$PREV" ]; then
            case "$state" in
                enabled)  log "自动更新: 启用" ;;
                disabled) log "自动更新: 禁用, watcher 睡眠" ;;
                invalid)  log "自动更新: 无效输入(第二行非0/1), 暂停更新" ;;
            esac
            PREV="$state"
        fi
        [ "$state" = "enabled" ] && sync_target
        sleep "$INTERVAL"
    done
    exit 0
fi

start_watcher() {
    if [ -f "$PID_FILE" ] && kill -0 "$(cat "$PID_FILE")" 2>/dev/null; then
        log "watcher 已在运行 pid=$(cat "$PID_FILE")"
        return 0
    fi
    rm -f "$PID_FILE"

    if [ ! -f "$SCRIPT_PATH" ]; then
        log "启动失败: $SCRIPT_PATH 不存在, 请把脚本放到该路径"
        return 1
    fi

    if command -v setsid >/dev/null 2>&1; then
        TRICKY_DAEMON=1 setsid sh "$SCRIPT_PATH" < /dev/null >> "$LOG" 2>&1 &
    else
        TRICKY_DAEMON=1 nohup sh "$SCRIPT_PATH" < /dev/null >> "$LOG" 2>&1 &
    fi
    for i in 1 2 3 4 5; do
        sleep 1
        [ -f "$PID_FILE" ] && kill -0 "$(cat "$PID_FILE")" 2>/dev/null && {
            log "watcher 已启动 pid=$(cat "$PID_FILE")"
            return 0
        }
    done
    log "watcher 启动失败, 请查看 $LOG"
    return 1
}

stop_watcher() {
    if [ -f "$PID_FILE" ]; then
        kill "$(cat "$PID_FILE")" 2>/dev/null
        rm -f "$PID_FILE"
        log "watcher 已停止"
    fi
}

status_watcher() {
    if [ -f "$PID_FILE" ] && kill -0 "$(cat "$PID_FILE")" 2>/dev/null; then
        echo "运行中 pid=$(cat "$PID_FILE")"
    else
        echo "未运行"
    fi
}

case "$1" in
    once)   sync_target ;;
    stop)   stop_watcher ;;
    status) status_watcher ;;
    start|*) sync_target; start_watcher ;;
esac
